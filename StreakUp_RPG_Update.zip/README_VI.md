# StreakUp — hướng dẫn cài và bật đồng bộ (Android)

## Bạn nhận được gì?
- Theo dõi mục tiêu học tập và thói quen hằng ngày.
- Chuỗi ngày, XP, cấp độ và huy hiệu.
- Lưu cục bộ trên trình duyệt.
- Có sẵn phần đăng nhập email/mật khẩu và đồng bộ Firestore; cần bạn tạo dự án Firebase miễn phí và điền cấu hình.
- Có thể cài như ứng dụng web (PWA) lên màn hình chính Android sau khi đưa lên HTTPS.

**Quan trọng:** Bản tải về chưa tự đồng bộ qua tài khoản cho đến khi bạn hoàn thành phần “Bật đồng bộ”. Đừng nhập dữ liệu quan trọng vào một bản demo chưa cấu hình.

## Phần A — Dùng thử ngay
1. Giải nén file ZIP.
2. Mở `public/index.html` để xem giao diện trên máy tính. Một số trình duyệt chặn tính năng module khi mở file trực tiếp; đăng nhập sẽ chưa hoạt động.
3. Trên Android, để dùng ổn định và cài lên màn hình chính, hãy triển khai thư mục `public` lên một dịch vụ HTTPS như Firebase Hosting.

## Phần B — Bật tài khoản và đồng bộ
Bạn chỉ cần làm một lần. Nếu các bước này khó, nhờ người lớn hoặc bạn biết máy tính hỗ trợ.

### 1. Tạo dự án Firebase
1. Mở https://console.firebase.google.com/ và đăng nhập Google.
2. Chọn **Create a project / Tạo dự án** và đặt tên, ví dụ `streakup-cua-toi`.
3. Trong trang dự án, bấm biểu tượng web `</>` để thêm ứng dụng web. Đặt tên `StreakUp`.
4. Firebase sẽ hiện một đoạn `firebaseConfig` gồm `apiKey`, `authDomain`, `projectId`, `messagingSenderId`, `appId`. Giữ trang đó mở.

### 2. Bật đăng nhập bằng email
1. Trong Firebase, mở **Build → Authentication**.
2. Bấm **Get started**.
3. Vào **Sign-in method**.
4. Chọn **Email/Password**, bật mục đầu tiên và bấm **Save**.

### 3. Tạo cơ sở dữ liệu
1. Mở **Build → Firestore Database**.
2. Bấm **Create database**.
3. Chọn chế độ Production và khu vực gần bạn nếu có.
4. Sau khi tạo xong, mở tab **Rules**.
5. Thay nội dung bằng file `firestore.rules` đi kèm trong ZIP rồi bấm **Publish**.
   Quy tắc này chỉ cho phép người dùng đọc/ghi tài liệu của chính tài khoản mình.

### 4. Điền cấu hình Firebase
1. Mở `public/index.html` bằng trình soạn thảo văn bản.
2. Tìm `const firebaseConfig = {`.
3. Thay các giá trị `PASTE_YOUR_...` bằng giá trị thật Firebase cung cấp. Giữ nguyên dấu nháy và dấu phẩy.
4. Lưu file.

Ví dụ cấu trúc (đây chỉ là mẫu, không dùng nguyên các giá trị này):
```js
const firebaseConfig = {
  apiKey: "giá-trị-thật-của-bạn",
  authDomain: "ten-du-an.firebaseapp.com",
  projectId: "ten-du-an",
  storageBucket: "ten-du-an.firebasestorage.app",
  messagingSenderId: "123456789",
  appId: "1:123456789:web:abcdef"
};
```

### 5. Đưa app lên mạng bằng Firebase Hosting
Cách này cần máy tính một lần để cài công cụ Firebase CLI:
1. Cài Node.js LTS từ https://nodejs.org/.
2. Mở Terminal/Command Prompt và chạy:
   `npm install -g firebase-tools`
3. Đăng nhập:
   `firebase login`
4. Trong thư mục dự án, chạy:
   `firebase init hosting`
5. Chọn dự án Firebase vừa tạo; thư mục public là `public`; cấu hình dưới dạng single-page app chọn `No`; không ghi đè `index.html`.
6. Chạy:
   `firebase deploy`
7. Mở URL HTTPS Firebase Hosting được cung cấp.

Nếu không có máy tính, hãy nhờ người thân hoặc bạn bè hỗ trợ phần triển khai. Không cần cài ứng dụng lạ từ file APK.

## Phần C — Cài lên màn hình chính Android
1. Mở URL HTTPS của app bằng Chrome trên điện thoại.
2. Bấm dấu ba chấm `⋮` ở góc trên.
3. Chọn **Add to Home screen / Thêm vào màn hình chính** hoặc **Install app / Cài đặt ứng dụng**.
4. Bấm **Add / Thêm**.
5. Mở StreakUp từ biểu tượng vừa tạo.

## Phần D — Đăng nhập và đổi điện thoại
1. Mở tab **Tài khoản**.
2. Nhập email và mật khẩu, bấm **Tạo tài khoản**.
3. Từ lần sau dùng cùng email/mật khẩu và URL app trên thiết bị khác.
4. Chờ thông báo đã tải dữ liệu từ đám mây.

## Lưu ý quan trọng
- Dữ liệu khách trước khi đăng nhập đang lưu trên trình duyệt hiện tại. Khi tạo tài khoản lần đầu, app có thể khởi tạo dữ liệu đám mây từ dữ liệu của máy. Đừng xóa dữ liệu trình duyệt trước khi đã đăng nhập và kiểm tra đồng bộ.
- Nếu đã có dữ liệu ở hai thiết bị, đừng đăng nhập trên cả hai rồi sửa cùng lúc trước khi kiểm tra; phiên bản khởi đầu này chưa có cơ chế giải quyết xung đột nâng cao.
- Không có cách nào đảm bảo giữ chuỗi nếu bạn không đánh dấu hoàn thành. Đừng đánh dấu việc chưa làm.
- Mỗi lần hoàn thành mục tiêu được cộng 10 XP; bỏ đánh dấu sẽ trừ lại 10 XP. Bản đầu chưa có thông báo nhắc giờ cố định.
- Firebase có gói miễn phí nhưng hạn mức và điều khoản có thể thay đổi. Không bật dịch vụ trả phí nếu bạn chưa hiểu rõ.
- Cấu hình Firebase web thường được dùng ở phía trình duyệt; quyền truy cập phải được bảo vệ bằng Authentication và Firestore Rules. Không đưa khóa riêng tư máy chủ (service account/private key) vào app.

## Cấu trúc thư mục
- `public/index.html` — ứng dụng
- `public/manifest.json` — thông tin cài lên màn hình chính
- `public/service-worker.js` — bộ đệm ngoại tuyến cơ bản
- `firestore.rules` — quy tắc bảo vệ dữ liệu người dùng

## Bản mở rộng Vượt ải (RPG)
Bản cập nhật có 10 quái vật tăng dần độ khó, cấp nhân vật dựa trên XP, xu thưởng khi hoàn thành mục tiêu, chiêu thức mở theo cấp, túi đồ và gacha 50 xu. Dữ liệu game lưu trên trình duyệt hiện tại; để chuyển máy/đồng bộ cần cấu hình Firebase. Để cập nhật GitHub Pages đã tạo, thay file `index.html` ở thư mục gốc của repository bằng file `public/index.html` trong gói cập nhật rồi Commit changes.
